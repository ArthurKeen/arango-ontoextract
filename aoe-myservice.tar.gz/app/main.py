import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import os
import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api import (
    admin,
    auth,
    curation,
    documents,
    er,
    extraction,
    health,
    metrics,
    notifications,
    ontology,
    orgs,
    quality,
    ws_curation,
    ws_extraction,
)
from app.api.auth import JWTAuthMiddleware
from app.api.errors import install_error_handlers
from app.api.metrics import PrometheusMiddleware
from app.api.rate_limit import RateLimitMiddleware
from app.config import settings
from app.db.client import close_db

logging.basicConfig(
    level=getattr(logging, settings.app_log_level.upper(), logging.INFO),
    format="%(levelname)-5s %(name)s: %(message)s",
)

structlog.configure(
    processors=[
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
)

log = structlog.get_logger()


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    log.info("starting", env=settings.app_env)
    yield
    close_db()
    log.info("shutdown_complete")


app = FastAPI(
    title="Arango-OntoExtract",
    description="LLM-driven ontology extraction and curation platform",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
)

install_error_handlers(app)

app.add_middleware(JWTAuthMiddleware)
app.add_middleware(PrometheusMiddleware)

if settings.rate_limit_enabled:
    app.add_middleware(RateLimitMiddleware)

app.include_router(auth.router)
app.include_router(health.router)
app.include_router(documents.router)
app.include_router(extraction.router)
app.include_router(admin.router)
app.include_router(ontology.router)
app.include_router(curation.router)
app.include_router(er.router)
app.include_router(orgs.router)
app.include_router(notifications.router)
app.include_router(metrics.router)
app.include_router(quality.router)
app.include_router(ws_extraction.router)
app.include_router(ws_curation.router)

# Serve static frontend files if they exist (Next.js export)
frontend_out = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "frontend", "out"
)
# Fallback for unified Docker image structure
if not os.path.isdir(frontend_out):
    frontend_out = "/app/static"

if os.path.isdir(frontend_out):
    app.mount("/", StaticFiles(directory=frontend_out, html=True), name="static")
else:
    log.warning("frontend_out_not_found", path=frontend_out)


